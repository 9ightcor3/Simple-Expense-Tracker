<div class="col-sm-12">
				<p class="back-link">Expense Tracker - Copyright @ Amshu & Rakesh</p>
			</div>